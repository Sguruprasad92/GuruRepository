package com.hospitalmanagement.src.utility;

/**
 * @author Lalusss
 * 
 */
public final class CommonConstants {

	private CommonConstants() {

	}

	/**
	 * for setting session max interval time
	 */
	public static final int sessionMaxInterval = 5 * 60;
	/**
	 * for logout page view name
	 */
	public static final String loginPage = "home";

	/**
	 * for exception page
	 */
	public static final String exceptionPage = "exception";

}
