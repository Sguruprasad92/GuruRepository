package com.hospitalmanagement.src.dao;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public class SearchPatientDAOImpl implements SearchPatientDAO {

	private static final Logger logger = Logger
			.getLogger(SearchPatientDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private HibernateTemplate template;

	@Override
	public PatientDtl getSearchPat(final int patientId) throws EMSException {
		String methodName = "getSearchPat(int patientId)";
		logger.debug("From SearchPatientDAOImpl where the method name is "
				+ methodName);
		Session session = null;
		PatientDtl patientDtl = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(PatientDtl.class);
			criteria.add(Restrictions.eq("patientId", patientId));
			patientDtl = (PatientDtl) criteria.uniqueResult();
		} catch (HibernateException e) {
			logger.error(e);
			throw new EMSException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
			} catch (HibernateException e) {
				logger.error(e);
			}
		}
		return patientDtl;
	}

}
