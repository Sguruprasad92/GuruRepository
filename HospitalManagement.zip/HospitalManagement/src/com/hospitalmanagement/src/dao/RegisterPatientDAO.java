package com.hospitalmanagement.src.dao;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public interface RegisterPatientDAO {
	/**
	 * @param employeeDtl
	 * @return boolean
	 * @throws EMSException
	 */
	public abstract String doRegistration(PatientDtl patientDtl)
			throws EMSException;

}
