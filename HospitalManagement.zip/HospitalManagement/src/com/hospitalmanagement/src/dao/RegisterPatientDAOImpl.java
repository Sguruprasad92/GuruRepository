package com.hospitalmanagement.src.dao;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public class RegisterPatientDAOImpl implements RegisterPatientDAO {

	private static final Logger logger = Logger
			.getLogger(RegisterPatientDAOImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private HibernateTemplate template;

	@Override
	public String doRegistration(final PatientDtl patientDtl)
			throws EMSException {
		String methodName = "doRegistration()";
		logger.debug("From RegisterPatientDAOImpl where the method name is : "
				+ methodName);
		Session session = null;
		Transaction transaction = null;
		int patientResult = 0;
		int loginResult = 0;
		String result = null;
		LoginInfoDtl loginInfo = null;
		try {
			loginInfo = new LoginInfoDtl();
			loginInfo.setUserId(patientDtl.getPatientId());
			loginInfo.setUserName(patientDtl.getPatFirstName());
			// loginInfo.setRoleType(patientDtl.getEmployeeRoleType());
			loginInfo.setPassword(patientDtl.getLoginPassword());
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			patientResult = (Integer) session.save(patientDtl);
			loginResult = (Integer) session.save(loginInfo);

			if ((patientResult == 0) && (loginResult == 0)) {
				result = null;
			} else {
				transaction.commit();
				result = "success";
			}
		} catch (HibernateException e) {
			throw new EMSException(e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return result;
	}
}
