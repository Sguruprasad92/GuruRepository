package com.hospitalmanagement.src.dao;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;

/**
 * @author admin
 * 
 */
public class LoginDAOImpl implements LoginDAO {

	private static final Logger logger = Logger.getLogger(LoginDAOImpl.class);

	@Autowired
	private HibernateTemplate template;

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public LoginInfoDtl validateLogin(int userId) {
		String methodName = "validateLogin()";
		logger.debug("From LoginDAO where the method name is " + methodName);

		LoginInfoDtl loginInfo = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(LoginInfoDtl.class);
			criteria.add(Restrictions.eq("userId", userId));
			loginInfo = (LoginInfoDtl) criteria.uniqueResult();
		} catch (HibernateException e) {
			logger.error(e);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return loginInfo;
	}

	@Override
	public LoginInfoDtl checkPatientId(final int empId) throws EMSException {
		String methodName = "checkEmployeeId()";
		logger.debug("From LoginDAO where the method name is " + methodName);
		Session session = null;
		LoginInfoDtl loginInfoDtl = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(LoginInfoDtl.class);
			criteria.add(Restrictions.eq("userId", empId));
			loginInfoDtl = (LoginInfoDtl) criteria.uniqueResult();
		} catch (HibernateException e) {
			logger.error(e);
			throw new EMSException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
			} catch (HibernateException e) {
				logger.error(e);
			}
		}
		return loginInfoDtl;
	}
}
