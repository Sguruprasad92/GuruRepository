package com.hospitalmanagement.src.dao;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public interface SearchPatientDAO {

	/**
	 * @param employeeId
	 * @return EmployeeDtl
	 * @throws EMSException
	 */
	public abstract PatientDtl getSearchPat(int patientId) throws EMSException;

}
