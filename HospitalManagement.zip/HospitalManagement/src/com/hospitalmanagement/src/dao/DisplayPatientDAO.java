package com.hospitalmanagement.src.dao;

import java.util.List;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public interface DisplayPatientDAO {

	/**
	 * @return List<EmployeeDtl>
	 * @throws EMSException
	 */
	public abstract List<PatientDtl> displayPatientList() throws EMSException;

}
