package com.hospitalmanagement.src.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Sajin
 * 
 */
public class DeletePatientDAOImpl implements DeletePatientDAO {

	private static final Logger logger = Logger
			.getLogger(DeletePatientDAOImpl.class);

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	HibernateTemplate template;

	@Override
	public List<PatientDtl> getPatientList() throws EMSException {
		String methodName = "getPatientList()";
		logger.debug("From DeletePatientDAOImpl where the method name is "
				+ methodName);
		List<PatientDtl> resultList = null;
		try {
			resultList = template.loadAll(PatientDtl.class);
		} catch (HibernateException exception) {
			logger.error(exception);
			throw new EMSException(exception);
		}
		return resultList;
	}

	@Override
	public String deletePatient(int patientId) throws EMSException {
		String methodName = "deletePatient()";
		logger.debug("From DeletePatientDAOImpl where the method name is "
				+ methodName);
		Session session = null;
		Transaction transaction = null;
		String result = null;
		int resultpatientDtl = 0;
		int resultloginDtl = 0;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Query query = session
					.createQuery("delete from PatientDtl p where p.patientId = :employeeId");
			query.setInteger("patientId", patientId);
			Query query1 = session
					.createQuery("delete from LoginInfoDtl l where l.userId = :usrId");
			query1.setInteger("usrId", patientId);
			resultpatientDtl = query.executeUpdate();
			resultloginDtl = query1.executeUpdate();
			if ((resultpatientDtl == 0) && (resultloginDtl == 0)) {
				result = null;
			} else {
				transaction.commit();
				result = "success";
			}
		} catch (HibernateException e) {
			throw new EMSException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
			} catch (HibernateException e) {
				logger.error(e);
			}
		}
		return result;
	}
}
