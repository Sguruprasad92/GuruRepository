package com.hospitalmanagement.src.dao;

import java.util.List;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public interface UpdatePatientDAO {

	/**
	 * @return List<EmployeeDtl>
	 * @throws EMSException
	 */
	public abstract List<PatientDtl> getPatientList() throws EMSException;

	/**
	 * @param employeeId
	 * @return EmployeeDtl
	 * @throws EMSException
	 */
	public abstract PatientDtl getPatForUpdate(int patientId)
			throws EMSException;

	/**
	 * @param employeeDtl
	 * @param loginInfoDtl
	 * @throws EMSException
	 */
	public abstract void updatePatient(PatientDtl patientDtl,
			LoginInfoDtl loginInfoDtl) throws EMSException;

}
