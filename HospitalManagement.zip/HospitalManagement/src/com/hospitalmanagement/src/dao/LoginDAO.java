package com.hospitalmanagement.src.dao;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;

/**
 * @author admin
 * 
 */
public interface LoginDAO {

	/**
	 * @param userId
	 * @return LoginInfoDtl
	 */
	public abstract LoginInfoDtl validateLogin(final int userId);

	/**
	 * @param empId
	 * @return LoginInfoDtl
	 * @throws EMSException
	 */
	public abstract LoginInfoDtl checkPatientId(int patId) throws EMSException;
}
