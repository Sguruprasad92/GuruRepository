package com.hospitalmanagement.src.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public class UpdatePatientDAOImpl implements UpdatePatientDAO {

	private static final Logger logger = Logger
			.getLogger(UpdatePatientDAOImpl.class);

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	HibernateTemplate template;

	@Override
	public List<PatientDtl> getPatientList() throws EMSException {
		String methodName = "getPatientList()";
		logger.debug("From UpdatePatientDAOImpl where the method name is "
				+ methodName);
		List<PatientDtl> resultList = null;
		try {
			resultList = template.loadAll(PatientDtl.class);
		} catch (HibernateException exception) {
			logger.error(exception);
			throw new EMSException(exception);
		}
		return resultList;
	}

	@Override
	public PatientDtl getPatForUpdate(final int patientId) throws EMSException {
		String methodName = "getPatForUpdate(int patientId)";
		logger.debug("From UpdatePatientDAOImpl where the method name is "
				+ methodName);
		Session session = null;
		PatientDtl employeeDtl = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(PatientDtl.class);
			criteria.add(Restrictions.eq("patientId", patientId));
			employeeDtl = (PatientDtl) criteria.uniqueResult();
		} catch (HibernateException e) {
			logger.error(e);
			throw new EMSException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
			} catch (HibernateException e) {
				logger.error(e);
			}
		}
		return employeeDtl;
	}

	@Override
	public void updatePatient(final PatientDtl patientDtl,
			final LoginInfoDtl loginInfoDtl) throws EMSException {
		String methodName = "updatePatient(PatientDtl patientDtl)";
		logger.debug("From UpdatePatientDAOImpl where the method name is "
				+ methodName);

		Session session = null;
		Transaction transaction = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.saveOrUpdate(patientDtl);
			session.saveOrUpdate(loginInfoDtl);
			transaction.commit();
		} catch (HibernateException e) {
			logger.error(e);
			throw new EMSException(e);
		} finally {
			try {
				if (session != null) {
					session.close();
				}
			} catch (HibernateException e) {
				logger.error(e);
			}
		}
	}
}
