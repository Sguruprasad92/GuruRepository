package com.hospitalmanagement.src.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public class DisplayPatientDAOImpl implements DisplayPatientDAO {
	private static final Logger logger = Logger
			.getLogger(DisplayPatientDAOImpl.class);

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	HibernateTemplate template;

	@Override
	public List<PatientDtl> displayPatientList() throws EMSException {
		String methodName = "displayPatient()";
		logger.debug("From DAO implement class method : " + methodName);
		List<PatientDtl> resultList = null;
		try {
			resultList = template.loadAll(PatientDtl.class);
		} catch (HibernateException exception) {
			logger.error(exception);
			throw new EMSException(exception);
		}

		return resultList;
	}
}
