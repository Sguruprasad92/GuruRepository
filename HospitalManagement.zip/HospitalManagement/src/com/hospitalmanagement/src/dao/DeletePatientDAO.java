package com.hospitalmanagement.src.dao;

import java.util.List;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Sajin
 * 
 */
public interface DeletePatientDAO {

	/**
	 * @return List<EmployeeDtl>
	 * @throws EMSException
	 */
	public abstract List<PatientDtl> getPatientList() throws EMSException;

	/**
	 * @param employeeId
	 * @return String
	 * @throws EMSException
	 */
	public abstract String deletePatient(int patientId) throws EMSException;

}
