package com.hospitalmanagement.src.service;

import java.util.List;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public interface DisplayService {
	/**
	 * @return List<EmployeeDtl>
	 * @throws EMSException
	 */

	public abstract List<PatientDtl> displayPatientList() throws EMSException;
}
