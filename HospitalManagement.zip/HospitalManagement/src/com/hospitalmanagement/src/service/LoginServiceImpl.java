package com.hospitalmanagement.src.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.dao.LoginDAO;
import com.hospitalmangement.src.bean.LoginInfoDtl;

/**
 * @author admin
 * 
 */
public class LoginServiceImpl implements LoginService {

	private static final Logger logger = Logger
			.getLogger(LoginServiceImpl.class);

	@Autowired
	private LoginDAO loginDAO;

	@Override
	public LoginInfoDtl validateLogin(final int userId) {
		String methodName = "validateLogin()";
		logger.debug("From LoginService where the method name is " + methodName);
		LoginInfoDtl loginInfo = loginDAO.validateLogin(userId);
		return loginInfo;
	}

	@Override
	public LoginInfoDtl checkPatientId(final int patId) throws EMSException {
		String methodName = "checkPatientId()";
		logger.debug("From LoginService where the method name is " + methodName);
		LoginInfoDtl loginInfoDtl = loginDAO.checkPatientId(patId);
		return loginInfoDtl;
	}
}
