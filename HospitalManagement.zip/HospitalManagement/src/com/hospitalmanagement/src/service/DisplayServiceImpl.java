package com.hospitalmanagement.src.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.dao.DisplayPatientDAO;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public class DisplayServiceImpl implements DisplayService {

	private static final Logger logger = Logger
			.getLogger(DisplayServiceImpl.class);

	@Autowired
	private DisplayPatientDAO displayPatientDAO;

	@Override
	public List<PatientDtl> displayPatientList() throws EMSException {
		String methodName = "displayEmployeeList()";
		logger.debug("From DisplayServiceImpl where the method name is : "
				+ methodName);
		List<PatientDtl> resultlist = displayPatientDAO.displayPatientList();
		return resultlist;
	}
}
