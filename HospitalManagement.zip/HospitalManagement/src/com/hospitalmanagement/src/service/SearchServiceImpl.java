package com.hospitalmanagement.src.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.dao.SearchPatientDAO;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Sajin
 *
 */
public class SearchServiceImpl implements SearchService {

	private static final Logger logger = Logger
			.getLogger(SearchServiceImpl.class);

	@Autowired
	private SearchPatientDAO searchPatientDao;

	@Override
	public PatientDtl getSearchPatient(final int patientId) throws EMSException {
		String methodName = "getSearchpatient(int patID)";
		logger.debug("From SearchServiceImpl where the method name is : "
				+ methodName);
		PatientDtl patientDtl = searchPatientDao.getSearchPat(patientId);
		return patientDtl;
	}

}
