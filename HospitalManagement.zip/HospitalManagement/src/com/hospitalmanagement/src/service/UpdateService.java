package com.hospitalmanagement.src.service;

import java.util.List;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Sajin
 * 
 */
public interface UpdateService {

	/**
	 * @return List<PatientDtl>
	 * @throws EMSException
	 */
	public abstract List<PatientDtl> getPatientList() throws EMSException;

	/**
	 * @param employeeId
	 * @return EmployeeDtl
	 * @throws EMSException
	 */
	public abstract PatientDtl getPatUpdate(final int patientId)
			throws EMSException;

	/**
	 * @param employeeDtl
	 * @param loginInfoDtl
	 * @throws EMSException
	 */
	public abstract void updatePatient(final PatientDtl patientDtl,
			final LoginInfoDtl loginInfoDtl) throws EMSException;

}
