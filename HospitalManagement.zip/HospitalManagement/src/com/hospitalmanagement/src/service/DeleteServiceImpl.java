package com.hospitalmanagement.src.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.dao.DeletePatientDAO;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Admin
 * 
 */
public class DeleteServiceImpl implements DeleteService {

	private static final Logger logger = Logger
			.getLogger(DeleteServiceImpl.class);

	@Autowired
	private DeletePatientDAO deletePatientDAO;

	@Override
	public List<PatientDtl> getPatientList() throws EMSException {
		String methodName = "getEmployeeList()";
		logger.debug("From DeleteServiceImpl where the method name is : "
				+ methodName);
		List<PatientDtl> resultlist = deletePatientDAO.getPatientList();
		return resultlist;
	}

	@Override
	public String deletePatient(final int patientId) throws EMSException {
		String methodName = "deletePatient()";
		logger.debug("From DeleteServiceImpl where the method name is : "
				+ methodName);
		String result = deletePatientDAO.deletePatient(patientId);
		return result;
	}

}
