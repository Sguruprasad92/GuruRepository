package com.hospitalmanagement.src.service;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.LoginInfoDtl;

/**
 * @author admin
 * 
 */
public interface LoginService {

	/**
	 * @param userId
	 * @return LoginInfoDtl
	 */
	public abstract LoginInfoDtl validateLogin(final int userId);

	/**
	 * @param empId
	 * @return LoginInfoDtl
	 * @throws EMSException
	 */
	public abstract LoginInfoDtl checkPatientId(final int patId)
			throws EMSException;
}
