package com.hospitalmanagement.src.service;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Sajin
 *
 */
public interface SearchService {

	/**
	 * @param employeeId
	 * @return EmployeeDtl
	 * @throws EMSException
	 */
	public abstract PatientDtl getSearchPatient(final int patientId)
			throws EMSException;

}
