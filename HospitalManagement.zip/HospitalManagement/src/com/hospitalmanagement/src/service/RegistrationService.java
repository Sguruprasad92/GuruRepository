package com.hospitalmanagement.src.service;

import com.hospitalmanagement.src.customException.EMSBusinessException;
import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public interface RegistrationService {
	/**
	 * @param employeeDtl
	 * @return boolean
	 * @throws EMSBusinessException
	 * @throws EMSException
	 * 
	 */
	public abstract String doRegistration(final PatientDtl patientDtl)
			throws EMSException, EMSBusinessException;
}
