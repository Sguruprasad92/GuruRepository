package com.hospitalmanagement.src.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalmanagement.src.customException.EMSBusinessException;
import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.dao.RegisterPatientDAO;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
public class RegistrationServiceImpl implements RegistrationService {

	private static final Logger logger = Logger
			.getLogger(RegistrationServiceImpl.class);

	@Autowired
	private RegisterPatientDAO registerPatientDAO;

	@Override
	public String doRegistration(final PatientDtl patientDtl)
			throws EMSException, EMSBusinessException {
		String methodName = "doRegistration()";
		logger.debug("From RegistrationServiceImpl where the method name is : "
				+ methodName);
		String result = registerPatientDAO.doRegistration(patientDtl);
		if (result.equals(null)) {
			throw new EMSBusinessException("Employee details not saved");
		}
		return result;
	}
}
