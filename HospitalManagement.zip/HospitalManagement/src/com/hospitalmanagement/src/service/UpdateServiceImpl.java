package com.hospitalmanagement.src.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.dao.UpdatePatientDAO;
import com.hospitalmangement.src.bean.LoginInfoDtl;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author Sajin
 * 
 */
public class UpdateServiceImpl implements UpdateService {

	private static final Logger logger = Logger
			.getLogger(UpdateServiceImpl.class);

	@Autowired
	private UpdatePatientDAO updatePatientDAO;

	@Override
	public List<PatientDtl> getPatientList() throws EMSException {
		String methodName = "getEmployeeList()";
		logger.debug("From UpdateServiceImpl where the method name is : "
				+ methodName);
		List<PatientDtl> resultlist = updatePatientDAO.getPatientList();
		return resultlist;
	}

	@Override
	public PatientDtl getPatUpdate(final int patientId) throws EMSException {
		String methodName = "getSearchPatient(int patID)";
		logger.debug("From SearchServiceImpl where the method name is : "
				+ methodName);
		PatientDtl patientDtl = updatePatientDAO.getPatForUpdate(patientId);
		return patientDtl;
	}

	@Override
	public void updatePatient(final PatientDtl patientDtl,
			LoginInfoDtl loginInfoDtl) throws EMSException {
		String methodName = "updatePatient(PatientDtl patientDtl)";
		logger.debug("From SearchServiceImpl where the method name is : "
				+ methodName);
		updatePatientDAO.updatePatient(patientDtl, loginInfoDtl);
	}
}
