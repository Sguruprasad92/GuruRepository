package com.hospitalmanagement.src.customException;

/**
 * @author admin
 * 
 */
@SuppressWarnings("serial")
public class EMSException extends Exception {

	/**
	 * Overridden constructor
	 */
	public EMSException() {
		super();
	}

	/**
	 * Overridden constructor
	 * 
	 * @param arg0
	 * @param arg1
	 */
	public EMSException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * Overridden constructor
	 * 
	 * @param arg0
	 */
	public EMSException(String arg0) {
		super(arg0);
	}

	/**
	 * Overridden constructor
	 * 
	 * @param arg0
	 */
	public EMSException(Throwable arg0) {
		super(arg0);
	}

}
