package com.hospitalmanagement.src.customException;

/**
 * @author admin
 * 
 */
@SuppressWarnings("serial")
public class EMSBusinessException extends Exception {

	/**
	 * Overridden constructor
	 */
	public EMSBusinessException() {
		super();
	}

	/**
	 * Overridden constructor
	 * 
	 * @param arg0
	 * @param arg1
	 */
	public EMSBusinessException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	/**
	 * Overridden constructor
	 * 
	 * @param arg0
	 */
	public EMSBusinessException(String arg0) {
		super(arg0);
	}

	/**
	 * Overridden constructor
	 * 
	 * @param arg0
	 */
	public EMSBusinessException(Throwable arg0) {
		super(arg0);
	}

}
