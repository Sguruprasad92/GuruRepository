package com.hospitalmangement.src.contrller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hospitalmanagement.src.service.LoginService;
import com.hospitalmanagement.src.utility.CommonConstants;
import com.hospitalmangement.src.bean.LoginInfoDtl;

/**
 * @author admin
 * 
 */
@Controller
public class LoginController {

	private static final Logger logger = Logger
			.getLogger(LoginController.class);

	@Autowired
	private LoginService loginService;

	/**
	 * @param userId
	 * @param password
	 * @param request
	 * @return String
	 */
	@RequestMapping(value = "/checkLogin", method = RequestMethod.POST)
	public ModelAndView validateLogin(int userId, String password,
			HttpServletRequest request) {
		System.out.println("khg");
		String methodName = "validateLogin()";
		logger.debug("From LoginController where the method name is "
				+ methodName);
		ModelAndView modelView = new ModelAndView();
		HttpSession session = null;
		LoginInfoDtl loginInfo = loginService.validateLogin(userId);
		System.out.println("From Controller:" + loginInfo);
		if (loginInfo != null) {
			if (password.equals(loginInfo.getPassword())) {
				session = request.getSession(true);
				session.setMaxInactiveInterval(CommonConstants.sessionMaxInterval);
				session.setAttribute("userName", loginInfo.getUserName());
				modelView.setViewName("welcomeLogin");
			} else {
				modelView.addObject("message", "Please enter a valid Password");
				modelView.setViewName(CommonConstants.loginPage);
			}
		} else {
			modelView.addObject("message", "Please enter a valid User Id");
			modelView.setViewName(CommonConstants.loginPage);
		}
		return modelView;
	}

	/**
	 * @param request
	 * @param session
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = "/doLogout", method = RequestMethod.POST)
	public String doLogout(HttpServletRequest request, HttpSession session,
			Model model) {
		request.getSession().invalidate();
		model.addAttribute("message", "Logout successfully");
		return CommonConstants.loginPage;

	}

}
