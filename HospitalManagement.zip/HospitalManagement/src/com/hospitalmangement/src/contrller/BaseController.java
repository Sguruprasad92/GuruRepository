package com.hospitalmangement.src.contrller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hospitalmanagement.src.customException.EMSBusinessException;
import com.hospitalmanagement.src.customException.EMSException;
import com.hospitalmanagement.src.service.DeleteService;
import com.hospitalmanagement.src.service.DisplayService;
import com.hospitalmanagement.src.service.LoginService;
import com.hospitalmanagement.src.service.RegistrationService;
import com.hospitalmanagement.src.service.SearchService;
import com.hospitalmanagement.src.service.UpdateService;
import com.hospitalmanagement.src.utility.CommonConstants;
import com.hospitalmangement.src.bean.LoginInfoDtl;
import com.hospitalmangement.src.bean.PatientBean;
import com.hospitalmangement.src.bean.PatientDtl;

/**
 * @author admin
 * 
 */
@Controller
public class BaseController {
	@Autowired
	private RegistrationService registrationService;

	@Autowired
	private DisplayService displayService;

	@Autowired
	private LoginService loginService;

	@Autowired
	private SearchService searchService;

	@Autowired
	private UpdateService updateService;

	@Autowired
	private DeleteService deleteService;

	private static final Logger logger = Logger.getLogger(BaseController.class);

	/**
	 * @return String
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String redirectHomePage() {
		String methodName = "redirectHomePage()";
		logger.debug("From BaseController where the method name is : "
				+ methodName);
		return CommonConstants.loginPage;
	}

	/**
	 * @param session
	 * @return ModelAndView
	 * @throws EMSException
	 */
	@RequestMapping(value = "/viewPatientDetails", method = RequestMethod.GET)
	public ModelAndView getDisplayEmployee(HttpSession session)
			throws EMSException {
		ModelAndView modelView = null;
		if (session.isNew()) {
			modelView = new ModelAndView();
			modelView.addObject("message", "Session Expired");
			modelView.setViewName(CommonConstants.loginPage);

		} else {

			modelView = new ModelAndView();
			String methodName = "getDisplayPatient()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			List<PatientDtl> resultList = displayService.displayPatientList();
			modelView.addObject("resultList", resultList);
			modelView.setViewName("viewPatientList");

		}
		return modelView;

	}

	/**
	 * @param model
	 * @param session
	 * @return String
	 * 
	 */
	@RequestMapping(value = "/registerPatient", method = RequestMethod.GET)
	public String getRegistration(Model model, HttpSession session) {
		if (session.isNew()) {
			model.addAttribute("message", "Session Expired");
			return CommonConstants.loginPage;
		} else {
			String methodName = "getRegistration()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			model.addAttribute("patientBean", new PatientBean());
			return "registerPatient";
		}

	}

	/**
	 * @param employeeBean
	 * @param result
	 * @param session
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = "/doRegistration", method = RequestMethod.POST)
	public String doRegistration(@Valid PatientBean patientBean,
			BindingResult result, HttpSession session, Model model) {
		if (session.isNew()) {
			model.addAttribute("message", "Session Expired");
			return CommonConstants.loginPage;
		} else {
			String methodName = "doRegistration()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			if (result.hasErrors()) {
				return "registerPatient";
			} else {
				try {
					PatientDtl patientDtl = new PatientDtl();

					patientDtl.setPatientId(patientBean.getPatId());
					patientDtl.setPatFirstName(patientBean.getPatFirstName());
					patientDtl.setPatientLastName(patientBean.getPatLastName());
					patientDtl.setPatientDesease(patientBean.getPatDesease());
					patientDtl.setGender(patientBean.getGender());
					DateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
					Date doj = dateFormat.parse(patientBean.getPatDoj());
					patientDtl.setPatDoj(doj);
					patientDtl.setBill(patientBean.getBill());
					patientDtl.setAge(patientBean.getAge());
					patientDtl.setWardNumber(patientBean.getWardNumber());
					patientDtl.setLoginPassword(patientBean.getLoginPassword());
					patientDtl.setAddedBy((String) session
							.getAttribute("userName"));
					String resultFlag = registrationService
							.doRegistration(patientDtl);
					if (!resultFlag.equals(null)) {
						model.addAttribute("message",
								"Patient Details Updated Successfully");
					}
				} catch (EMSException | EMSBusinessException | ParseException e) {
					e.printStackTrace();
				}
				return "registerPatient";
			}
		}
	}

	/**
	 * @param empId
	 * @param session
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = "/checkEmployeeId", method = RequestMethod.POST)
	@ResponseBody
	public String checkEmployeeId(@RequestBody String patId,
			HttpSession session, Model model) {
		if (session.isNew()) {
			model.addAttribute("message", "Session Expired");
			return CommonConstants.loginPage;
		} else {
			String methodName = "chechkEmployeeId()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			int patientId = Integer.valueOf(patId);
			String returnValue = null;
			LoginInfoDtl loginInfoDtl = null;
			try {
				loginInfoDtl = loginService.checkPatientId(patientId);
				if (loginInfoDtl != null) {
					returnValue = "error";
				} else {
					returnValue = "success";
				}
			} catch (EMSException e) {
				logger.error(e);
			}
			return returnValue;
		}
	}

	/**
	 * @param session
	 * @param model
	 * @return String
	 */
	@RequestMapping(value = "/searchPatient", method = RequestMethod.GET)
	public String getSearchPatient(HttpSession session, Model model) {
		if (session.isNew()) {
			model.addAttribute("message", "Session Expired");
			return CommonConstants.loginPage;
		} else {
			String methodName = "getSearchPatient()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			return "searchPatientPage";
		}
	}

	/**
	 * @param employeeId
	 * @param employeeName
	 * @param session
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/doSearch", method = RequestMethod.POST)
	public ModelAndView doSearchPatient(int patientId, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView();
		if (session.isNew()) {
			modelAndView.addObject("message", "Session Expired");
			modelAndView.setViewName(CommonConstants.loginPage);
			return modelAndView;
		} else {
			String methodName = "doSearchPatient()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			PatientBean patientBean = new PatientBean();
			try {

				PatientDtl patientDtl = searchService
						.getSearchPatient(patientId);
				if (patientDtl == null) {
					modelAndView.addObject("message",
							"No employees found for given patientId");
					modelAndView.setViewName("searchPPage");
				} else {
					patientBean.setPatId(patientDtl.getPatientId());
					patientBean.setPatFirstName(patientDtl.getPatFirstName());
					patientBean.setPatLastName(patientDtl.getPatientLastName());
					patientBean.setPatDesease(patientDtl.getPatientDesease());
					patientBean.setGender(patientDtl.getGender());

					String doj = new SimpleDateFormat("dd/MMM/yyyy")
							.format(patientDtl.getPatDoj());

					patientBean.setPatDoj(doj);

					patientBean.setBill(patientDtl.getBill());
					patientBean.setAge(patientDtl.getAge());
					patientBean.setWardNumber(patientDtl.getWardNumber());
					patientBean.setLoginPassword(patientDtl.getLoginPassword());
					modelAndView.addObject("patientBean", patientBean);
					modelAndView.setViewName("getSearchPat");
				}
			} catch (EMSException e) {
				logger.error(e);
				e.printStackTrace();
			}
			return modelAndView;
		}
	}

	/**
	 * @param session
	 * @param model
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/updatePatient", method = RequestMethod.GET)
	public ModelAndView getUpdatePage(HttpSession session) {
		if (session.isNew()) {
			ModelAndView modelView = new ModelAndView();
			modelView.addObject("message", "Session Expired");
			modelView.setViewName(CommonConstants.loginPage);
			return modelView;
		} else {
			ModelAndView modelView = new ModelAndView();
			String methodName = "getUpdatePage()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			List<PatientDtl> resultList = null;
			try {
				resultList = updateService.getPatientList();
				modelView.addObject("patientBean", new PatientDtl());
				modelView.addObject("patList", resultList);
				modelView.setViewName("updatePatient");
			} catch (EMSException e) {
				e.printStackTrace();
			}
			return modelView;
		}
	}

	/**
	 * @param employeeDtll
	 * @param employeeId
	 * @param session
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/redirectToUpdate", method = RequestMethod.POST)
	public ModelAndView redirectUpdate(PatientDtl patientDtll,
			HttpSession session) {
		ModelAndView modelAndView = new ModelAndView();
		if (session.isNew()) {
			modelAndView.addObject("message", "Session Expired");
			modelAndView.setViewName(CommonConstants.loginPage);
			return modelAndView;
		} else {
			String methodName = "redirectUpdate()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			PatientBean patientBean = new PatientBean();
			try {

				PatientDtl patientDtl = updateService.getPatUpdate(patientDtll
						.getPatientId());
				if (patientDtl == null) {
					modelAndView.addObject("message",
							"No patients found for given patientId");
					modelAndView.setViewName("searchPatientPage");
				} else {
					patientBean.setPatId(patientDtl.getPatientId());
					patientBean.setPatFirstName(patientDtl.getPatFirstName());
					patientBean.setPatLastName(patientDtl.getPatientLastName());
					patientBean.setPatDesease(patientDtl.getPatientDesease());
					patientBean.setGender(patientDtl.getGender());

					String doj = new SimpleDateFormat("dd/MMM/yyyy")
							.format(patientDtl.getPatDoj());

					patientBean.setPatDoj(doj);

					patientBean.setBill(patientDtl.getBill());
					patientBean.setAge(patientDtl.getAge());
					patientBean.setWardNumber(patientDtl.getWardNumber());
					patientBean.setLoginPassword(patientDtl.getLoginPassword());
					modelAndView.addObject("patientBean", patientBean);
					modelAndView.setViewName("getPatForUpdate");
				}
			} catch (EMSException e) {
				logger.error(e);
				e.printStackTrace();
			}
			return modelAndView;
		}
	}

	/**
	 * @param session
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/deletePatient", method = RequestMethod.GET)
	public ModelAndView getDeleteListPage(HttpSession session) {
		if (session.isNew()) {
			ModelAndView modelView = new ModelAndView();
			modelView.addObject("message", "Session Expired");
			modelView.setViewName(CommonConstants.loginPage);
			return modelView;
		} else {
			ModelAndView modelView = new ModelAndView();
			String methodName = "getDeleteListPage()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			List<PatientDtl> resultList = null;
			try {
				resultList = deleteService.getPatientList();
				modelView.addObject("patientBean", new PatientDtl());
				modelView.addObject("patList", resultList);
				modelView.setViewName("deletePatient");
			} catch (EMSException e) {
				e.printStackTrace();
			}
			return modelView;
		}
	}

	/**
	 * @param employeeDtl
	 * @param session
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/deletePatient", method = RequestMethod.POST)
	public ModelAndView deletePatient(PatientDtl patientDtl, HttpSession session) {
		if (session.isNew()) {
			ModelAndView modelView = new ModelAndView();
			modelView.addObject("message", "Session Expired");
			modelView.setViewName(CommonConstants.loginPage);
			return modelView;
		} else {
			ModelAndView modelView = new ModelAndView();
			String methodName = "deletePatient()";
			logger.debug("From BaseController where the method name is : "
					+ methodName);
			List<PatientDtl> resultList = null;
			String deleteResult = null;
			try {
				deleteResult = deleteService.deletePatient(patientDtl
						.getPatientId());
				if (deleteResult.equals(null)) {
					modelView.addObject("error", "Patient Not Deleted");
				} else {
					modelView.addObject("message",
							"Patient deleted successfully");
				}
				resultList = deleteService.getPatientList();
				modelView.addObject("patientBean", new PatientDtl());
				modelView.addObject("patList", resultList);
				modelView.setViewName("deletePatient");
			} catch (EMSException e) {
				e.printStackTrace();
			}
			return modelView;
		}
	}

	/**
	 * @param json
	 * @param session
	 * @param model
	 * @return String
	 */

	@RequestMapping(value = "/updatePatDetails", method = RequestMethod.POST)
	@ResponseBody
	public String updatePatientDetails(@RequestBody String json,
			HttpSession session, Model model) {
		if (session.isNew()) {
			model.addAttribute("message", "Session Expired");
			return CommonConstants.loginPage;
		} else {
			try {
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(json);
				int patId = Integer.parseInt((String) jsonObject.get("empId"));
				String patFirstName = (String) jsonObject.get("patFirstName");
				String patLastName = (String) jsonObject.get("patLastName");
				String patDesease = (String) jsonObject.get("patDesease");
				String patGender = (String) jsonObject.get("patGender");
				double patBill = Double.parseDouble((String) jsonObject
						.get("patBill"));
				int patAge = (int) Double.parseDouble((String) jsonObject
						.get("patAge"));
				int patWardNum = Integer.parseInt((String) jsonObject
						.get("patWardNum"));
				String patPassword = (String) jsonObject.get("patPassword");
				PatientDtl patientDtl = new PatientDtl();
				LoginInfoDtl loginInfoDtl = new LoginInfoDtl();
				PatientDtl patlDtl = updateService.getPatUpdate(patId);
				LoginInfoDtl infoDtl = loginService.checkPatientId(patId);
				if (patlDtl != null) {
					patientDtl = patlDtl;
				}
				if (infoDtl != null) {
					loginInfoDtl = infoDtl;
				}
				patientDtl.setPatientId(patId);
				patientDtl.setPatFirstName(patFirstName);
				patientDtl.setPatientLastName(patLastName);
				patientDtl.setPatientDesease(patDesease);
				patientDtl.setGender(patGender);
				patientDtl.setBill(patBill);
				patientDtl.setAge(patAge);
				patientDtl.setWardNumber(patWardNum);
				patientDtl.setLoginPassword(patPassword);
				patientDtl
						.setAddedBy((String) session.getAttribute("userName"));
				loginInfoDtl.setUserName(patFirstName);
				loginInfoDtl.setUserId(patId);
				loginInfoDtl.setPassword(patPassword);
				updateService.updatePatient(patientDtl, loginInfoDtl);

			} catch (org.json.simple.parser.ParseException | EMSException e) {
				e.printStackTrace();
			}
			return "success";
		}
	}
}
