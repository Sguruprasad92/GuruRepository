package com.hospitalmangement.src.bean;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author Admin
 * 
 */
@SuppressWarnings("serial")
public class PatientBean implements Serializable {

	// @NotNull(message = "Id should not empty")
	// @Range(min = 4, max = 4, message = "Id should have minimum length of 4")
	private int patId;

	@NotEmpty(message = "First name should not empty")
	private String patFirstName;

	@NotEmpty(message = "Last name should not empty")
	private String patLastName;

	@NotEmpty(message = "Patient desease should not empty")
	private String patDesease;

	@NotEmpty(message = "Admint date should not empty")
	private String patDoj;

	// @NotNull(message = "Basic Should Not Be Null")
	// @NotEmpty(message = "Basic should not empty")
	// @Range(min = 4, message = "Basic should have minimum 4 digit")
	private double bill;

	// @NotEmpty(message = "Commision should not empty")
	// @Range(min = 4, message = "commision should have minimum 4 digit")
	private int wardNumber;

	// @NotEmpty(message = "Department num should not empty")
	// @Range(min = 2, max = 2, message =
	// "Department num should have minimum length of 2")
	private String gender;

	private int age;

	public int getAge() {
		return age;
	}

	public void setAge(final int age) {
		this.age = age;
	}

	@NotEmpty(message = "Password should not empty")
	@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[@#$!%]).{8,16})", message = "It must contain atleast 1 digit, 1 lowercase and uppercase character, 1 of these char @#!$% and length between 8 to 16")
	@Size(min = 8, max = 16, message = "Password length should be in between 8 to 16")
	private String loginPassword;

	/**
	 * @return empId
	 */
	public Integer getPatId() {
		return patId;
	}

	/**
	 * @param empId
	 */
	public void setPatId(Integer patId) {
		this.patId = patId;
	}

	/**
	 * @return patFirstName
	 */
	public String getPatFirstName() {
		return patFirstName;
	}

	/**
	 * @param patFirstName
	 */
	public void setPatFirstName(final String patFirstName) {
		this.patFirstName = patFirstName;
	}

	/**
	 * @return empLastName
	 */
	public String getPatLastName() {
		return patLastName;
	}

	/**
	 * @param empLastName
	 */
	public void setPatLastName(final String patLastName) {
		this.patLastName = patLastName;
	}

	/**
	 * @return patDoj
	 */
	public String getPatDoj() {
		return patDoj;
	}

	/**
	 * @param patDoj
	 */
	public void setPatDoj(final String patDoj) {
		this.patDoj = patDoj;
	}

	/**
	 * @return empSal
	 */
	public Double getBill() {
		return bill;
	}

	/**
	 * @param empSal
	 */
	public void setBill(final double bill) {
		this.bill = bill;
	}

	public void setEmpDeptNum(final int empDeptNum) {
		this.wardNumber = empDeptNum;
	}

	/**
	 * @return loginPassword
	 */
	public String getLoginPassword() {
		return loginPassword;
	}

	/**
	 * @param loginPassword
	 */
	public void setLoginPassword(final String loginPassword) {
		this.loginPassword = loginPassword;
	}

	@Override
	public String toString() {
		return "EmployeeBean [empId=" + patId + ", empFirstName="
				+ patFirstName + ", empLastName=" + patLastName + ", doj="
				+ patDoj + ", empSal=" + bill + ", empDeptNum=" + wardNumber
				+ ", loginPassword=" + loginPassword + "]";
	}

	public String getPatDesease() {
		return patDesease;
	}

	public void setPatDesease(String patDesease) {
		this.patDesease = patDesease;
	}

	public int getWardNumber() {
		return wardNumber;
	}

	public void setWardNumber(int wardNumber) {
		this.wardNumber = wardNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setPatId(int patId) {
		this.patId = patId;
	}

}
