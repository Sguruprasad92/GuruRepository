package com.hospitalmangement.src.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author admin
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "loginInfoDetailsOfPatient")
public class LoginInfoDtl implements Serializable {

	@Id
	@Column(name = "userId")
	private int userId;

	@Column(name = "userName")
	private String userName;

	/*
	 * @Column(name = "roleType") private String roleType;
	 */
	@Column(name = "password")
	private String password;

	/**
	 * no-arg constructor
	 */
	public LoginInfoDtl() {

	}

	/**
	 * @return employeeId
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 */
	public void setUserId(final int userId) {
		this.userId = userId;
	}

	/**
	 * @return userId
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 */
	public void setUserName(final String userName) {
		this.userName = userName;
	}

	/**
	 * @return roleType
	 */
	/*
	 * public String getRoleType() { return roleType; }
	 *//**
	 * @param roleType
	 */
	/*
	 * public void setRoleType(final String roleType) { this.roleType =
	 * roleType; }
	 */
	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 */
	public void setPassword(final String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "LoginInfoDtl [userId=" + userId + ", userName=" + userName
				+ ", password=" + password + "]";
	}
}
