package com.hospitalmangement.src.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author admin
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "patient")
public class PatientDtl implements Serializable {

	private int patientId;
	private String patientFirstName;
	private String patientLastName;
	private String gender;
	private int age;
	private String patientDesease;
	private double bill;
	private int wardNumber;
	private String loginPassword;
	private String addedBy;
	private Date patDoj;

	@Column(name = "age")
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return employeeId
	 */
	@Id
	@Column(name = "patId")
	public int getPatientId() {
		return patientId;
	}

	/**
	 * @param employeeId
	 */
	public void setPatientId(final int patientId) {
		this.patientId = patientId;
	}

	/**
	 * @return employeeFirstName
	 */
	@Column(name = "patientFirstName")
	public String getPatFirstName() {
		return patientFirstName;
	}

	/**
	 * @param employeeFirstName
	 */
	public void setPatFirstName(final String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	/**
	 * @return employeeLastName
	 */
	@Column(name = "patientLastName")
	public String getPatientLastName() {
		return patientLastName;
	}

	/**
	 * @param patientLastName
	 */
	public void setPatientLastName(final String patientLastName) {
		this.patientLastName = patientLastName;
	}

	/**
	 * @return patientDesease
	 */
	@Column(name = "patientDesease")
	public String getPatientDesease() {
		return patientDesease;
	}

	/**
	 * @param patientDesease
	 */
	public void setPatientDesease(final String patientDesease) {
		this.patientDesease = patientDesease;
	}

	/**
	 * @return gender
	 */
	@Column(name = "gender")
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 */
	public void setGender(final String gender) {
		this.gender = gender;
	}

	/**
	 * @return patdoj
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "patDoj")
	public Date getPatDoj() {
		return patDoj;
	}

	/**
	 * @param patdoj
	 */
	public void setPatDoj(final Date patDoj) {
		this.patDoj = patDoj;
	}

	/**
	 * @return bill
	 */
	@Column(name = "bill")
	public double getBill() {
		return bill;
	}

	/**
	 * @param bill
	 */
	public void setBill(final double bill) {
		this.bill = bill;
	}

	/**
	 * @return wardNumber
	 */
	@Column(name = "wardNumber")
	public int getWardNumber() {
		return wardNumber;
	}

	/**
	 * @param wardNumber
	 */
	public void setWardNumber(final int wardNumber) {
		this.wardNumber = wardNumber;
	}

	/**
	 * @return loginPassword
	 */
	public String getLoginPassword() {
		return loginPassword;
	}

	/**
	 * @param loginPassword
	 */
	public void setLoginPassword(final String loginPassword) {
		this.loginPassword = loginPassword;
	}

	/**
	 * @return addedBy
	 */
	@Column(name = "addedBy")
	public String getAddedBy() {
		return addedBy;
	}

	/**
	 * @param addedBy
	 */
	public void setAddedBy(final String addedBy) {
		this.addedBy = addedBy;
	}

	@Override
	public String toString() {
		return "EmployeeDtl [patientId=" + patientId + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName
				+ ", gender=" + gender + ", age=" + age + ", patientDesease="
				+ patientDesease + ", bill=" + bill + ", wardNumber="
				+ wardNumber + ", loginPassword=" + loginPassword
				+ ", addedBy=" + addedBy + ", patDoj=" + patDoj + "]";
	}

}
