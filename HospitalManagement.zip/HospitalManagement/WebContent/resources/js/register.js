/**
 * Created by Sajin for register employee
 */

$(document).ready(function() {
	$(function() {
		$("#patDoj").datepicker({
			changeMonth : true,
			changeYear : true,
			dateFormat : 'dd/M/yy'
		});
	});
	$("#patientId").val("");
	$("#bill").val("");
	$("#age").val("");
	$("#wardNumber").val("");
});

function validate(evt) {
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /[0-9\b]|\t/;
	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}
function valChar(evt) {
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /[a-zA-Z\b]|\s|\|\t./;
	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}
function valAlphNum(evt) {
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	var regex = /[a-zA-Z0-9\b]|\s|\t/;
	if (!regex.test(key)) {
		theEvent.returnValue = false;
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}

function valPassword(evt) {
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode(key);
	//var regex = /[a-zA-Z0-9\b]|\s|\t/;
	var regex = /^(?=.*[a-z])[A-Za-z0-9\d=!\-@._*]+$/;
	if (!regex.test(key)) {
		theEvent.returnValue = false;
		alert("test");
		if (theEvent.preventDefault)
			theEvent.preventDefault();
	}
}

var pageName = "Register Patient";
function registerSubmit() {
	if ($("#patientId").val() == "") {
		jAlert("Enter the Patient ID", pageName);
	} else if ($("#patientFirstName").val() == "") {
		jAlert("Enter the Patient First Name", pageName);
	} else if ($("#patientLastName").val() == "") {
		jAlert("Enter the Patient Last Name", pageName);
	} else if ($("#patientDesease").val() == "") {
		jAlert("Select the Patient Job", pageName);
	} else if ($("#gender").val() == "") {
		jAlert("Select the Patient Gender", pageName);
	} else if ($("#patDoj").val() == "") {
		jAlert("Select date of Joining", pageName);
	} else if ($("#bill").val() == "") {
		jAlert("Enter the Basic Bill", pageName);
	} else if ($("#age").val() == "") {
		jAlert("Enter the Patient age", pageName);
	} else if ($("#wardNumber").val() == "") {
		jAlert("Enter the ward number", pageName);
	} else if ($("#loginPassword").val() == "") {
		jAlert("Enter the login password", pageName);
	} else {
		$("#doRegistrationPage").attr('action', "doRegistration");
		$("#doRegistrationPage").submit();
	}
}

function checkPatId() {
	var patId = $("#patientId").val();
	var finalUrl = "checkPatientId";
	$.ajax({
		url : finalUrl,
		type : "POST",
		data : patId,
		beforeSend : function(xhr) {
			xhr.setRequestHeader("Accept", "text/plain");
			xhr.setRequestHeader("Content-Type", "text/plain");
		},
		success : function(response) {
			if (response == "error") {
				jAlert("Patient Id already exist", pageName);
				$("#patientId").val("");
			}
		}
	});
}

function resetForm() {
	$("#patientId").val("");
	$("#patientFirstName").val("");
	$("#patientLastName").val("");
	$("#patientDesease").val("");
	$("#gender").val("");
	$("#patDoj").val("");
	$("#bill").val("");
	$("#age").val("");
	$("#wardNumber").val("");
	$("#loginPassword").val("");
}
