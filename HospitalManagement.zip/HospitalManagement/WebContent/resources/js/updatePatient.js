/**
 * created by sajin for Update employee
 */

var pageName = "Update Patient";

function redirectTo(patId)
{
	$("#patientId").val(patId);
	$("#redirectToUpdate").submit();
}

function updatePatient(){
	jAlert("test",pageName);
}

function resetPatient(){
	$("#patientFirstName").val("");
	$("#patientLastName").val("");
	$("#patientDesease").val("");
	$("#gender").val("");
	$("#bill").val("");
	$("#age").val("");
	$("#wardNumber").val("");
	$("#loginPassword").val("");
}

function validate(evt) {
	  var theEvent = evt || window.event;
	  var key = theEvent.keyCode || theEvent.which;
	  key = String.fromCharCode( key );
	  var regex = /[0-9\b]|\t/;
	  if( !regex.test(key) ) {
	    theEvent.returnValue = false;
	    if(theEvent.preventDefault) theEvent.preventDefault();
	  }
	}
function valChar(evt) {
	  var theEvent = evt || window.event;
	  var key = theEvent.keyCode || theEvent.which;
	  key = String.fromCharCode( key );
	  var regex = /[a-zA-Z\b]|\s|\|\t./;
	  if( !regex.test(key) ) {
	    theEvent.returnValue = false;
	    if(theEvent.preventDefault) theEvent.preventDefault();
	  }
	}
function valAlphNum(evt) {
	  var theEvent = evt || window.event;
	  var key = theEvent.keyCode || theEvent.which;
	  key = String.fromCharCode( key );
	  var regex = /[a-zA-Z0-9\b]|\s|\t/;
	  if( !regex.test(key) ) {
	    theEvent.returnValue = false;
	    if(theEvent.preventDefault) theEvent.preventDefault();
	  }
}

function valPassword(evt) {
	  var theEvent = evt || window.event;
	  var key = theEvent.keyCode || theEvent.which;
	  key = String.fromCharCode( key );
	  //var regex = /[a-zA-Z0-9\b]|\s|\t/;
	  var regex = /^(?=.*[a-z])[A-Za-z0-9\d=!\-@._*]+$/;
	  if( !regex.test(key) ) {
	    theEvent.returnValue = false;
	    alert("test");
	    if(theEvent.preventDefault) theEvent.preventDefault();
	  }
}

function updatePatient(){
	var patId = $("#patientId").val();
	var patFirstName = $("#patientFirstName").val();
	var patLastName = $("#patientLastName").val();
	var patDesease = $("#patientDesease").val();
	var patGender = $("#gender").val();
	//var empDoj = $("#doj").val();
	var patBill = $("#bill").val();
	var patAge = $("#age").val();
	var patWardNum = $("#wardNumber").val();
	var patPassword = $("#loginPassword").val();
	var data = {};
	data.patId = patId;
	data.patFirstName = patFirstName;
	data.patLastName = patLastName;
	data.patDesease = patDesease;
	data.patGender = patGender;
	//data.empDoj = empDoj;
	data.patBill = patBill;
	data.patAge = patAge;
	data.patWardNum = patWardNum;
	data.patPassword = patPassword;
	var finalUrl = "updatePatDetails";
	$.ajax({
		url:finalUrl,
		type:"POST",
		data:JSON.stringify(data),
		beforeSend: function(xhr) {  
		    xhr.setRequestHeader("Accept", "text/plain");  
		xhr.setRequestHeader("Content-Type", "application/json");  
		},
		success: function(response){
			if(response == "success"){
				$("#updateButtons").css("display","none");
				$("#updateMessage").css("display","block");
			}
        }
	});
	
}




