package com.marlabs.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author Admin
 *
 */
@Configuration
@ComponentScan(basePackages = { "com.marlabs.dao", "com.marlabs.service" })
public class RootConfig {

}
