package com.marlabs.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

/**
 * @author Admin
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.marlabs.controller" })
public class WebConfiguration extends WebMvcConfigurerAdapter {

	/**
	 * @return Internal
	 */
	public InternalResourceViewResolver viewResovler() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/jsp");
		viewResolver.setSuffix(".jsp");
		return viewResolver;
	}

}
