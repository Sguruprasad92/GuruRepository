package com.marlabs.dao;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.marlabs.model.Restaurant;

/**
 * @author Admin
 *
 */
@Repository
public class RestaurantDaoImpl implements RestaurantDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@SuppressWarnings("unused")
	@Override
	@Transactional
	public boolean addRestaurant(Restaurant restaurant) {
		String Method_Name = "addRestaurant()";
		System.out.println("Method Invoked :" + Method_Name + "with" + restaurant);
		Serializable Id = hibernateTemplate.save(restaurant);
		boolean addFlag = true;
		System.out.println("Response from Method:" + Method_Name + "with" + addFlag);
		return addFlag;
	}

	@Override
	@Transactional
	public List<Restaurant> getRestaurantList(int restaurantId) {
		String Method_Name = "getRestaurantList()";
		System.out.println("Mrthod Invoked : " + Method_Name + "with" + restaurantId);
		List<Restaurant> restaurantList = hibernateTemplate.loadAll(Restaurant.class);
		restaurantList = hibernateTemplate.loadAll(Restaurant.class);
		System.out.println("Response from Method:" + Method_Name + "with" + restaurantList);

		return restaurantList;
	}

	@Override
	@Transactional
	public boolean deleteRestaurant(int restaurantId) {
		String Method_Name = "delete()";
		System.out.println("Method Invoked : " + Method_Name + "with" + restaurantId);
		Restaurant restaurant = hibernateTemplate.load(Restaurant.class, restaurantId);
		hibernateTemplate.delete(restaurant);
		boolean deleteFlag = true;
		System.out.println("Response from Method:" + Method_Name + "with" + deleteFlag);
		return deleteFlag;
	}

	@Override
	@Transactional
	public boolean updateRestaurant(Restaurant restuarant) {
		String Method_Name = "update()";
		System.out.println(" Method Invoked:" + Method_Name + "with" + restuarant);
		hibernateTemplate.saveOrUpdate(restuarant);
		boolean updateFlag = true;
		System.out.println("Response from Method:" + Method_Name + "with" + updateFlag);
		return updateFlag;

	}

}
