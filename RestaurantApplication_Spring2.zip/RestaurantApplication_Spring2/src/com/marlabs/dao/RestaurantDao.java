package com.marlabs.dao;

import java.util.List;

import com.marlabs.model.Restaurant;

/**
 * @author Admin
 *
 */
public interface RestaurantDao {

	/**
	 * @param restaurant
	 * @return boolean
	 */
	public abstract boolean addRestaurant(final Restaurant restaurant);

	/**
	 * @param restaurantId
	 * @return List<Restaurant>
	 */
	public abstract List<Restaurant> getRestaurantList(final int restaurantId);

	/**
	 * @param restaurantId
	 * @return boolean
	 */
	public abstract boolean deleteRestaurant(final int restaurantId);

	/**
	 * @param restaurant
	 * @return boolean
	 */
	public abstract boolean updateRestaurant(final Restaurant restaurant);

}
