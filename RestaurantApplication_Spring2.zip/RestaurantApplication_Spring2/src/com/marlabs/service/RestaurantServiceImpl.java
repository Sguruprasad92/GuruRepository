package com.marlabs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marlabs.dao.RestaurantDao;
import com.marlabs.model.Restaurant;

/**
 * @author Admin
 *
 */
@Service
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	private RestaurantDao restaurantDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.marlabs.service.RestaurantService#addRestaurant(com.marlabs.model.
	 * Restaurant)
	 */
	@Override
	public boolean addRestaurant(Restaurant restaurant) {
		String Method_Name = "addRestaurant()";
		System.out.println("Method Invoked:" + Method_Name + "with" + restaurant);
		boolean addFlag = false;
		addFlag = restaurantDao.addRestaurant(restaurant);
		System.out.println("Response from Mehod:" + Method_Name + "with" + addFlag);
		return addFlag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.marlabs.service.RestaurantService#getRestaurantList(int)
	 */
	@Override
	public List<Restaurant> getRestaurantList(int restaurantId) {
		String Method_Name = "getRestaurant()";
		System.out.println("Method Invoked: " + Method_Name + "with" + restaurantId);
		List<Restaurant> restaurantList = restaurantDao.getRestaurantList(restaurantId);
		System.out.println("Response from Mehod:" + Method_Name + "with" + restaurantList);
		return restaurantList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.marlabs.service.RestaurantService#updateRestaurant(com.marlabs.model.
	 * Restaurant)
	 */
	@Override
	public boolean updateRestaurant(Restaurant restaurant) {
		String Method_Name = "updateRestaurant()";
		System.out.println("Method Invoked:" + Method_Name + "with" + restaurant);
		boolean updateFlag = false;
		updateFlag = restaurantDao.addRestaurant(restaurant);
		System.out.println("Response from Mehod:" + Method_Name + "with" + updateFlag);
		return updateFlag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.marlabs.service.RestaurantService#deleteRestaurant(int)
	 */
	@Override
	public boolean deleteRestaurant(final int restaurantId) {
		String Method_Name = "deleteRestaurant";
		System.out.println("Method Invoked: " + Method_Name + "with" + restaurantId);
		boolean deleteFlag = false;
		deleteFlag = restaurantDao.deleteRestaurant(restaurantId);
		System.out.println("Response from Mehod:" + Method_Name + "with" + deleteFlag);
		return deleteFlag;
	}

}
