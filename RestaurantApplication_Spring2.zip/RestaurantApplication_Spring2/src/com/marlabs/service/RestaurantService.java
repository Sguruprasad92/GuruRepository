package com.marlabs.service;

import java.util.List;

import com.marlabs.model.Restaurant;

/**
 * @author Admin
 *
 */
public interface RestaurantService {

	/**
	 * @param restaurant
	 * @return boolean
	 */
	public abstract boolean addRestaurant(Restaurant restaurant);

	/**
	 * @param restaurantId
	 * @return List<Restaurant>
	 */
	public abstract List<Restaurant> getRestaurantList(final int restaurantId);

	/**
	 * @param restaurant
	 * @return boolean
	 */
	public abstract boolean updateRestaurant(Restaurant restaurant);

	/**
	 * @param restaurantId
	 * @return boolean
	 */
	public abstract boolean deleteRestaurant(final int restaurantId);

}
