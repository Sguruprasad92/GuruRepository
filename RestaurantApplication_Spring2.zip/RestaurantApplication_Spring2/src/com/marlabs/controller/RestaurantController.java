package com.marlabs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.marlabs.model.Restaurant;
import com.marlabs.service.RestaurantService;

/**
 * @author Admin
 *
 */
@Controller
public class RestaurantController {

	@Autowired
	private RestaurantService restaurantService;

	/**
	 * @param model
	 * @param restaurant
	 * @return String
	 */
	@SuppressWarnings("unused")
	@RequestMapping("/addRestaurant.htm")
	public String addRestaurant(Model model, @ModelAttribute("restaurant") Restaurant restaurant) {
		String Method_Name = "addRestaurant()";
		System.out.println("Method Invoked : " + Method_Name + "with" + restaurant);
		model.addAttribute("restaurant", restaurant);
		boolean restaurant1 = restaurantService.addRestaurant(restaurant);
		String outputJsp = "addRestaurant";
		System.out.println("Response from Method:" + Method_Name + "with" + outputJsp);
		return outputJsp;
	}

	/**
	 * @param model
	 * @param restaurantId
	 * @return String
	 */
	@RequestMapping("/getRestaurant.htm")
	public String getRestaurantList(Model model, int restaurantId) {
		String Method_Name = "getRestaurantList()";
		System.out.println("Method Invoked : " + Method_Name);
		List<Restaurant> restaurantList = restaurantService.getRestaurantList(restaurantId);
		model.addAttribute("restaurantList", restaurantList);
		String outJsp = "getRestaurant";
		System.out.println("Response from Method:" + Method_Name + "with" + outJsp);
		return outJsp;

	}

	/**
	 * @param model
	 * @param restaurant
	 * @return String
	 */
	@RequestMapping("/updateRestaurant.jsp")
	public String updateRestaurant(Model model, Restaurant restaurant) {
		String Method_Name = "updateRestaurant";
		System.out.println("Method Invoked : " + Method_Name);
		boolean restaurant1 = restaurantService.updateRestaurant(restaurant);
		System.out.println(restaurant1);
		model.addAttribute("restaurant", restaurant);
		String outJsp = "updateRestaurant";
		System.out.println("Response from Method:" + Method_Name + "with" + outJsp);
		return outJsp;
	}

	/**
	 * @param model
	 * @param restaurantId
	 * @return String
	 */
	public String deleteRestaurant(Model model, int restaurantId) {
		String Method_Name = "deleteRestaurant()";
		System.out.println("Method Invoked : " + Method_Name + "with" + restaurantId);
		model.addAttribute("restaurant", restaurantId);
		boolean restaurant1 = restaurantService.deleteRestaurant(restaurantId);
		System.out.println(restaurant1);
		String outputJsp = "deleteRestaurant";
		System.out.println("Response from Method:" + Method_Name + "with" + outputJsp);
		return outputJsp;
	}

}
